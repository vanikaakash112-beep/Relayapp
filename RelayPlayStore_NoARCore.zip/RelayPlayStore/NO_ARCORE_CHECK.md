# Relay — No ARCore build

Checked the Android project for ARCore / Google Play Services for AR references.

- No `com.google.ar.core` manifest metadata
- No `android.hardware.camera.ar` feature declaration
- No `com.google.ar.core` / `play-services-ar` Gradle dependency
- No ARCore API calls such as `ArCoreApk.requestInstall()`
- No camera permission is requested

This Relay app is a normal WebView-based app and does not require Google Play Services for AR.

Google's ARCore documentation notes that AR-required apps are limited to ARCore-supported devices; removing the AR-required feature/metadata avoids that AR-specific requirement.

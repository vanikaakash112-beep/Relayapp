# Relay — Play Store Android setup

This is an Android Studio project that wraps the Relay HTML/CSS/JS frontend in a native Android WebView.

Package ID: `com.relay.app`
Version: `1.0` / versionCode `1`

## Build in Android Studio
1. Install Android Studio on a PC/Mac.
2. Open this `RelayPlayStore` folder.
3. Let Gradle sync and install Android SDK Platform 35 if Android Studio asks.
4. For a test APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For Play Store: **Build > Generate Signed Bundle / APK > Android App Bundle**.
6. Create a new `.jks` keystore and keep its password/recovery details safe.
7. Choose `release` and build the `.aab`.
8. In Google Play Console, create the app, upload the signed AAB, complete the store listing, app content, data safety, testing and release requirements, then submit for review.

## Important before publishing
- Replace the package ID if you want a different permanent ID. Once published, the package ID should not be changed.
- Add a real app icon and Play Store screenshots before release.
- The current frontend is a UI prototype; real message relay/backend functionality still needs to be connected.
- Do not put your keystore/password inside the project or upload it to GitHub.

## ARCore compatibility check
The project was checked and contains no ARCore dependency or AR-required manifest declaration. Relay does not request camera access and does not require Google Play Services for AR.

const form=document.getElementById('relayForm');
const input=document.getElementById('username');
const result=document.getElementById('result');

form.addEventListener('submit',e=>{
  e.preventDefault();
  const name=input.value.trim();
  if(name.length<3 || name.length>24){
    input.focus();
    result.textContent='Please choose a username between 3 and 24 characters.';
    result.classList.add('show');
    return;
  }
  if(!/^[a-zA-Z0-9._-]+$/.test(name)){
    result.textContent='Use letters, numbers, dots, underscores or hyphens only.';
    result.classList.add('show');
    return;
  }
  localStorage.setItem('relayUsername',name);
  result.textContent=`Your Relay name is @${name}`;
  result.classList.add('show');
});

const saved=localStorage.getItem('relayUsername');
if(saved) input.value=saved;
